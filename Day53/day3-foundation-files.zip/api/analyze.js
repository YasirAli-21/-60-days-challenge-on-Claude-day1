// api/analyze.js
//
// DAY 3 STATUS: This is a connection-test STUB, not the real analysis engine.
// It proves the full pipeline works: Frontend -> Vercel Function -> Claude API -> back to Frontend.
// The real analysis logic (prompt from prompts/analysisPrompt.js, full JSON schema,
// validation, retry-on-malformed-JSON) is built on Day 5. Do not add real logic here yet.

const Anthropic = require("@anthropic-ai/sdk");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed. Use POST." });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({
      error: "Server misconfiguration: ANTHROPIC_API_KEY is not set.",
    });
  }

  try {
    const anthropic = new Anthropic({ apiKey });

    // Hardcoded test message for today only — confirms the API key + SDK + network path all work.
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-5-20250929", // Confirm this is still the current recommended model before Day 5 real usage.
      max_tokens: 200,
      messages: [
        {
          role: "user",
          content:
            "Reply with exactly this JSON and nothing else: {\"status\": \"connected\", \"message\": \"AI Career Copilot backend is talking to Claude successfully.\"}",
        },
      ],
    });

    const textBlock = response.content.find((block) => block.type === "text");

    return res.status(200).json({
      ok: true,
      raw: textBlock ? textBlock.text : null,
    });
  } catch (err) {
    console.error("Claude API test call failed:", err);
    return res.status(502).json({
      error: "Could not reach the Claude API. Check your API key and network connection.",
      details: err.message,
    });
  }
};
